declare function getCountryFlag(country: string): string;

export default getCountryFlag;