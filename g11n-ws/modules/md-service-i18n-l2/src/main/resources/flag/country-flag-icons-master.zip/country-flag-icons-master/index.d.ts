export function hasFlag(country: string): boolean;
export const countries: string[];
