'use strict'

exports.hasFlag = require('./commonjs/hasFlag.js').default
exports.countries = require('./commonjs/countries.json')