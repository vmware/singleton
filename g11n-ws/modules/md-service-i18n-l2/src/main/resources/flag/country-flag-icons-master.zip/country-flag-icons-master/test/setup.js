import chai, { expect } from 'chai'

global.expect = expect
chai.should()